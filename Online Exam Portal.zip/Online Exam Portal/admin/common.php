<?php
    $con = mysqli_connect("localhost","root","","exams") or die(mysqli_error($con));
?>