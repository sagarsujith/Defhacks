<?php
    include 'common.php';
?>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-xs-4">
                <h3>Information</h3>
                <p><a href="aboutus.php">About Us</a></p>
                <p><a href="contactus.php">Contact Us</a></p>
            </div>
            <div class="col-xs-4">
                <h3>Links</h3>
                  
                                    
                <p><a href="home.php">Home</a></p>
               
                <p><a href="viewsub.php">View Subject</a></p>
                
                <p><a href="testview.php">View Test</a></p>
                
                <p><a href="questiondelete.php">View Question</a></p>
                
                <p><a href="showuser.php">View User</a></p>

                <p><a href="logout.php">Logout</a></p>
                           
            </div>
            <div class="col-xs-4">
                <h3>About Us</h3>
                <p>Developed by Fine Crew</p>
                <p>Contact Us:+91 9581381907</p>
                <p>Email:finecrew@gmail.com</p>
                <p>Proudly Developed in INDIA !</p>
            </div>
        </div>
    </div>
</footer>