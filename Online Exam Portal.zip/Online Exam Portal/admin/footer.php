<?php
    include 'common.php';
?>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-xs-6">
                <h3>Information</h3>
                <p><a href="#">About Us</a></p>
                <p><a href="#">Contact Us</a></p>
            </div>
            <div class="col-xs-6">
                <h3>About Us</h3>
                <p>Developed by Fine Crew</p>
                <p>Contact Us:+91 9581381907</p>
                <p>Email:finecrew@gmail.com</p>
                <p>Proudly Developed in INDIA !</p>
            </div>
        </div>
    </div>
</footer>